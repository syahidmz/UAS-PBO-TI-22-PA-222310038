package com.ibik.pbo.uas;

public class Staff {
	//constructor staff
	private String id_staff;
	private String nama;
	private String jabatan;
	private String alamat;
	private String no_telepon;
	private String username;
	private String password;
	
	
	//pojo / setget buat attribut staff
	public String getIdstaff() {
		return id_staff;
	}
	
	public void setIdstaff(String id_staff) {
		this.id_staff = id_staff;
	}
	
	public String getNama() {
		return nama;
	}
	
	public void setNama(String nama) {
		this.nama = nama;
	}
	
	public String getJabatan() {
		return jabatan;
	}
	
	public void setJabatan(String jabatan) {
		this.jabatan = jabatan;
	}
	
	public String getAlamat() {
		return alamat;
	}
	
	public void setAlamat(String alamat) {
		this.alamat = alamat;
	}
	
	public String getNotlpn() {
		return no_telepon;
	}
	
	public void setNotlpn(String no_telepon) {
		this.no_telepon = no_telepon;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	


}
